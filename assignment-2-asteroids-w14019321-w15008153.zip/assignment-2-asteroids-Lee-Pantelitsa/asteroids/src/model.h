/* Asteroids Model */
struct point {
    float x,y;
};
typedef struct point coordinate_t;
typedef struct point vector_t;

/* Some insitial struct types if you want to use them */
struct ship {
		int heading;
    coordinate_t p;
    vector_t     v;
};
/* initial struts for building linked lists */
struct rock {
    coordinate_t p;
    struct rock *next;
};

struct missile {
	int heading;
	vector_t v;
  coordinate_t p;
	float ttl;
  struct missile *next;
};

void physics(void);
void fire();
extern int missileSlots;