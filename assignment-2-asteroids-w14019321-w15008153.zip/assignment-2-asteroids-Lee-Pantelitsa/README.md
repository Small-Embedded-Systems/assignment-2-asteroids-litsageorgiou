# Asteroid-Assignment-Base
Initial skeleton for the assignment (semester-2 2016/17)

This is the starting point for the Semester 2 assignment.
The asteroids directory has a sample set of code to start with.

## asteroids
asteroids.cpp:
 this is the entry point to the program.  It defines some of the global variables that capture the state of the game
asteroids.h:
  This exports the global varables for use in other modules
  
## controller
base code for the controller, user interface for the 

## view
base code for the view (graphics)

## model 
model.cpp:
 Base code for the model of the game (in my solution the arrays used for all the objects are in here).
 All the logic for moving and interactions of objects.
 
