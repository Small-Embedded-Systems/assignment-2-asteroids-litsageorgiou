/* Asteroids
    Sample solution for assignment
    Semester 2 -- Small Embedded Systems
    Dr Alun Moon
*/

/* C libraries */
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>

/* hardware platform libraries */
#include <display.h>
#include <mbed.h>

/* Main game elements */
#include "model.h"
#include "view.h"
#include "controller.h"

/* Game state */
float elapsed_time; 
int   score;
int   lives;
struct ship player;
struct missile *shots;

float Dt = 0.01f;

Ticker model, view, controller;
void init_game();
bool paused = true;
/* The single user button needs to have the PullUp resistor enabled */
DigitalIn userbutton(P2_10,PullUp);

/* This is the first method that starts when the application begins */
int main()
{
    init_DBuffer();
    view.attach( draw, 0.025);
    model.attach( physics, Dt);
    controller.attach( controls, 0.1);
    init_game();
    //lives =5;	

    /* Pause to start */
    while( userbutton.read() ){ /* remember 1 is not pressed */
        paused=true;
        wait_ms(100);
    }
    paused = false;
    
    while(true) {
        /* do one of */
        /* Wait until all lives have been used
        while(lives>0){
            // possibly do something game related here
            wait_ms(200);
        }
        */
        /* Wait until each life is lost
        while( inPlay ){
            // possibly do something game related here
            wait_ms(200);
        }
        */
    }
}

void init_game(){
	player.p.x = 200;
	player.p.y = 136;
	player.v.x = 0;
	player.v.y = 0;
	lives = 5;
	score = 0;
	elapsed_time = 0;
}
