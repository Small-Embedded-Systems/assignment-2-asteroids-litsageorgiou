/* Asteroids view
*/

/* C libraries */
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>

/* hardware platform libraries */
#include <display.h>
#include <mbed.h>

#include "asteroids.h"
#include "model.h"
#include "utils.h"

Display *graphics = Display::theDisplay();

const colour_t background = RED;

const coordinate_t shape[] = {
    {0,-10}, {-5,5}, {5,5}
};

/* double buffering functions */
void init_DBuffer(void)
{   /* initialise the LCD driver to use second frame in buffer */
    uint16_t *bufferbase = graphics->getFb();
    uint16_t *nextbuffer = bufferbase+ (480*272);
    LPC_LCD->UPBASE = (uint32_t)nextbuffer;
}

void swap_DBuffer(void)
{   /* swaps frames used by the LCD driver and the graphics object */
    uint16_t *buffer = graphics->getFb();
    graphics->setFb( (uint16_t*) LPC_LCD->UPBASE);
    LPC_LCD->UPBASE = (uint32_t)buffer;
}

/* Using the methods */
void draw_sidebar(int score, float elapsed_time, int lives);
void draw_missiles(struct missile *shots);
void draw_ship(struct ship);
struct missile *active = NULL;

/* Initiates the methods to draw the display */
void draw(void)
{
  graphics->fillScreen(background);

  draw_sidebar(score, elapsed_time, lives);
  draw_missiles(active);
  draw_ship(player);
  swap_DBuffer();
}

/* The draw sidebar method draws the sidebar which contains the information */
void draw_sidebar(int score, float elapsed_time, int lives){
	graphics->fillRect(400, 0,80, 272, BLACK);
	graphics->setTextColor(WHITE, BLACK);
	graphics->setTextSize(1);
	
	graphics->setCursor(403, 2);
	graphics->printf("CM0506");
	graphics->setCursor(403, 17);
	graphics->printf("Created by:");
	
	graphics->fillCircle(403, 36, 2, BLUE);
	graphics->setCursor(409, 32);
	graphics->printf("w14019321");
	
	graphics->fillCircle(403, 49, 2, BLUE);
	graphics->setCursor(409, 45);
	graphics->printf("w15008153");

	graphics->setCursor(403, 75);
	graphics->printf("Score:%d", score);
	graphics->setCursor(403, 90);
	graphics->printf("Time:	%d", elapsed_time);
	graphics->setCursor(403, 105);
	graphics->printf("Lives: %i", missileSlots);
	if(lives == 5){
		missileSlots = 5;
	}else	if(lives == 4){
		missileSlots = 4;
	}else	if(lives == 3){
		missileSlots = 3;
	}else	if(lives == 2){
		missileSlots = 2;
	}else if(lives == 1){
		missileSlots = 1;
	}

	graphics->drawCircle(150,200,18,WHITE);
	graphics->drawCircle(200,100,15,WHITE);
	graphics->drawCircle(300,200,19,WHITE);
}

/* The draw missiles method draws the missiles which are used by the ship */
void draw_missiles(missile *shots){
	for( ; shots ; shots=shots->next ) {	
		graphics->drawCircle(shots->p.x,shots->p.y,5,RED);
	}
}

/* The draw ship method draws the ship */
void draw_ship(struct ship){
	float tra0x = player.p.x + (shape[0].x*cos(radians(player.heading))) - (shape[0].y*sin(radians(player.heading)));
	float tra0y = player.p.y + (shape[0].x*sin(radians(player.heading))) + (shape[0].y*cos(radians(player.heading)));
	float tra1x = player.p.x + (shape[1].x*cos(radians(player.heading))) - (shape[1].y*sin(radians(player.heading))); 
	float tra1y = player.p.y + (shape[1].x*sin(radians(player.heading))) + (shape[1].y*cos(radians(player.heading)));
	float tra2x = player.p.x + (shape[2].x*cos(radians(player.heading))) - (shape[2].y*sin(radians(player.heading)));
	float tra2y = player.p.y + (shape[2].x*sin(radians(player.heading))) + (shape[2].y*cos(radians(player.heading)));

	graphics->drawTriangle(tra0x, tra0y, tra1x, tra1y,tra2x,tra2y, YELLOW);
}