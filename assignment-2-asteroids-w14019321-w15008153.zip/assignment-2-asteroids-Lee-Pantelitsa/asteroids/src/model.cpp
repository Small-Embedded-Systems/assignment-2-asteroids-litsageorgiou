/* Asteroids model */
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

#include "model.h"
#include "utils.h"
#include "asteroids.h"
#include "view.h"
#include "math.h"

/* If you want to initialise a linked list:
    You'll have to replace node_t with the right type

typedef struct missile {
    some data per node
    struct node *next;
} node_t;
*/
//void new_missile(struct missile *r);
//static const int heapsize = 10;
//static missile heap[heapsize];
//static missile *freenodes;
//void initialise_heap(void)
//{
//    int n;
//    for( n=0 ; n<(heapsize-1) ; n++) {
//        heap[n].next = &heap[n+1];
//    }
//    heap[n].next = NULL;
//    freenodes = &heap[0];
//}

//missile *allocnode(void)
//{
//    missile *node = NULL;
//    if( freenodes ) {
//        node = freenodes;
//        freenodes = freenodes->next;
//    }
//    return node;
//}

//void freenode(missile *n)
//{
//    n->next = freenodes;
//    freenodes = n;
//}

int missileSlots;
float xN = sin(radians(player.heading));
	float xy = cos(radians(player.heading));

struct missile *initialise()
{
    int c;
		const size_t MAXSize = 10;
    for(c=0 ; c<(MAXSize-1) ; c++){
        shots[c].next = &shots[c+1];
    }
    shots[c].next = NULL;
    return shots;
}
void fire() {
	struct missile *newShots = (struct missile*) malloc(sizeof(struct missile));
		newShots->heading = player.heading;
	newShots->p.x = player.p.x + xN;
	newShots->p.y = player.p.y + xy; 
	newShots->heading = player.heading;
	newShots->next = shots;
	shots = newShots;
	missileSlots++;
}
//void new_missile(struct missile *r){
//	r->heading = player.heading;
//	
//	r->p.x = player.p.x;
//	r->p.y = player.p.y;
//	
//	r->v.x = sin(radians(r->heading));
//	r->v.y = -cos(radians(r->heading));
//	
//	r->p.x += r->v.x*20;
//	r->p.y += r->v.y*20;
//	
//	r->v.x *=50;
//	r->v.y *=50;
//	
//	r->ttl = 20;

//}
void move_missiles(missile *shots) {

	for( ; shots ; shots=shots->next ) {
		shots->p.x += sin(radians(shots->heading));
		shots->p.y -= cos(radians(shots->heading));
	}
}

ship move_ship(ship, float Dt); 
//void move_missiles(struct missile *r);
//void move_missiles(missile *shots);
//void update_missile_list();
void physics(void)
{
  //if(!paused){
		player = move_ship(player, Dt);
		move_missiles(shots);
	//asteroids = new_astroids(asteroids);
		//move_asteroids(astroids, Dt);
		
		//missile_hit_rocks(shots, asteroids);
		//if(ship_hits(asteroids){
		//	paused = true;
		// 								<----------------- new life stuff
		//}
	//update_missile_list();
	//update_rock_list()
	//}
}

/* Ensures the player can move the ship from one side to another and wraps around the screen */
ship move_ship(ship, float time){
  player.p.x += player.v.x;
	player.p.y += player.v.y;
	
	player.v.x = player.v.x - (player.v.x * time);
	player.v.y = player.v.y - (player.v.y * time);
	
	if(player.p.x < 0){
		player.p.x += 400;
	}
	if(player.p.x >= 400){
		player.p.x -= 400;
	}
	if(player.p.y < 0){
 		player.p.y += 272;
	}
	if(player.p.y >= 272){
		player.p.y -= 272;
	}		
	return player;
}

struct missile *shothead(struct missile *shots) {
	if( shots ){
			while(missileSlots == 10){
				struct missile *discard = shots;
				shots = shots->next;
				free(shots);
			}
	}
return shots;
}
void *removeShot(struct missile *shots) {
	shots = shothead(shots);
	for( ; shots ; shots=shots->next ) {
	shots->next = shothead( shots->next );
	}
	return shots;
}
